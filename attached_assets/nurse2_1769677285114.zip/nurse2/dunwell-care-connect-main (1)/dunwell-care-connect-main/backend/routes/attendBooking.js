import express from "express";
import { pool } from "../db.js";

const router = express.Router();

router.post("/", async (req, res) => {
  const { appointID, examination, history, diagnoses, treatment, healthEducation, followUpPlan } = req.body;

  const client = await pool.connect();

  try {
    // Update visit info (FollowUp_Plan as NVARCHAR(MAX))
    await client.request()
      .input("appointID", appointID)
      .input("Examination", examination)
      .input("History", history)
      .input("Diagnoses", diagnoses)
      .input("Treatment", treatment)
      .input("HealthEducation", healthEducation)
      .input("FollowUpPlan", followUpPlan)
      .query(`
        UPDATE Visits
        SET
          Examination = @Examination,
          History = @History,
          Diagnoses = @Diagnoses,
          Treatment = @Treatment,
          Health_Education = @HealthEducation,
          FollowUp_Plan = @FollowUpPlan
        WHERE AppointID = @appointID
      `);

    // Create new appointment if follow-up datetime exists
    if (followUpPlan) {
      const oldAppointResult = await client.request()
        .input("appointID", appointID)
        .query("SELECT * FROM Appointments WHERE AppointID = @appointID");

      const oldAppoint = oldAppointResult.recordset[0];
      if (!oldAppoint) throw new Error("Original appointment not found");

      const followUpDate = new Date(followUpPlan);
      if (isNaN(followUpDate.getTime())) throw new Error("Invalid follow-up datetime");

      await client.request()
        .input("PatientID", oldAppoint.PatientID)
        .input("MedicalAidNumber", oldAppoint.MedicalAidNumber)
        .input("StartTime", followUpDate)
        .input("EndTime", null)
        .input("UserID", oldAppoint.UserID)
        .input("MedicalAidName", oldAppoint.MedicalAidName)
        .input("Status", "Scheduled")
        .input("ServiceName", oldAppoint.ServiceName)
        .input("ServicePrice", oldAppoint.ServicePrice)
        .input("MedicalAid_MainMember", oldAppoint.MedicalAid_MainMember)
        .input("MainMember__IDNo", oldAppoint.MainMember__IDNo)
        .input("MedicalAid_option", oldAppoint.MedicalAid_option)
        .input("PaymentMethod", oldAppoint.PaymentMethod)
        .input("FinalPrice", oldAppoint.FinalPrice)
        .input("IsStudent", oldAppoint.IsStudent)
        .input("isFollow_Up", "YES")
        .query(`
          INSERT INTO Appointments (
            PatientID, MedicalAidNumber, StartTime, EndTime, UserID,
            MedicalAidName, Status, ServiceName, ServicePrice,
            MedicalAid_MainMember, MainMember__IDNo, MedicalAid_option,
            PaymentMethod, FinalPrice, IsStudent, isFollow_Up
          )
          VALUES (
            @PatientID, @MedicalAidNumber, @StartTime, @EndTime, @UserID,
            @MedicalAidName, @Status, @ServiceName, @ServicePrice,
            @MedicalAid_MainMember, @MainMember__IDNo, @MedicalAid_option,
            @PaymentMethod, @FinalPrice, @IsStudent, @isFollow_Up
          )
        `);
    }

    client.close();
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    client.close();
    res.status(500).json({ message: "Failed to record visit or create follow-up" });
  }
});

export default router;
